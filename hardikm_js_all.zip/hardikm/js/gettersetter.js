'use strict';

console.log("Getter Setter Method Class Example");
var shop = {
	id : {brand:'polo',type:'t-shirt'},
	color:'royal Blue',
	price : '25$'

};

Object.defineProperty(shop,'detail',{

	get:function(){
		return this.id.brand +' '+ this.id.type;
	},
	set:function(value){
		var idpart= value.split(' ');
		this.id.brand= idpart[0];
		this.id.type= idpart[1];
	}
})

shop.detail = 'Rolex Watch IHIH';
console.info(shop.detail);
console.info(shop.detail.brand);
console.info(shop.detail.type);