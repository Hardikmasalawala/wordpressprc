  'use strict';
alert("array.js is calling");

var CallDisp = function(alt) { alert(alt);};
CallDisp("Hardik");