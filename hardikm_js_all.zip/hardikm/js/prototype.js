'use prototype';

function Animal(voice)
{
	this.voice= voice || "Martin";	
}
Animal.prototype.speak= function()
{
	console.log(this.voice);
	//console.log('Martin');
}

function Cat(name,color)
{
	Animal.call(this,'Mili');
	this.name=name;
	this.color=color;
}
Cat.prototype = Object.create(Animal.prototype);
Cat.prototype.constructor = Cat;
 var minnie = new Cat('minnie','Brown');

 minnie.speak();
 console.log("minnie.__proto__ : "+ (minnie.__proto__));
 console.log("minnie.__proto__.__proto__ : "+ (minnie.__proto__.__proto__));
 console.log("minnie instanceof Animal : "+ (Cat instanceof Animal));