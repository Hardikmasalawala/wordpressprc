var Calc = require('./nodeClac.js');
new Calc(0)
	.add(1)
	.add(2)
	.multi(3)
	.equal( function(result){
			console.log("Final result :"+result);
	} );

