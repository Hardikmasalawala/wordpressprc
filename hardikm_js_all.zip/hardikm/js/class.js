'use strict';
console.log("Class Example");
function Person(name, gender){

   // Add object properties like this
   this.name = name;
   this.gender = gender;
}
Person.prototype.disp = function()
{
  console.log("Name:"+ this.name);
  console.log("Gender:"+ this.gender);
};
var person = new Person("Bob", "M");
person.disp();


function Shop(id,brand,color,price)
	{
		this.id=id;
		this.brand=brand;
		this.color=color;
		this.price=price;
	}

Shop.prototype.disp= function()
	{
		document.write("<br>--Product Detail--");
		document.write("<br>Id:"+this.id);
		document.write("<br>Brand:"+this.brand);
		document.write("<br>Color:"+this.color);
		document.write("<br>Price:"+this.price);
		document.write("<br>------------------<br>");
	};	


var s1= new Shop('Watch','Fastrack','Black','800$');
s1.disp();
var s2= new Shop('T-shirt','Edwardy','Black','10$');
s2.disp();