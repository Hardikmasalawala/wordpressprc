'use strict';
  console.log("Object Example");
 function shop(id,price)
 {
 	this.id = id;
 	this.price = price;
 }
  var customer = new shop('Polo t-shirt','599');
  console.log(customer);