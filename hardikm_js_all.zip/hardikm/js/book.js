var Book = function(name,price){
var priceChanging = [],
	priceChanged = [];

	this.name = function(val){
			return name;
	};
	this.price = function(val){
			if(val !== undefined && val !== price ){
				for (var i = 0; i < priceChanging.length; i++) {
					if(!priceChanging[i](this,val)){
						return price;
						}
				}
				price = val;
				for (var i = 0; i < priceChanged.length; i++) {
					priceChanged[i](this);
				}
			}

			return price;
	};

	this.onPriceChanging = function(callback){
		priceChanging.push(callback);
	};
	this.onPriceChanged = function(callback){
		priceChanged.push(callback);
	};
};

var b1 = new Book('js:The Good Part', 202);

console.log("Book Name : " + b1.name());
console.log("Book Price : " + b1.price());

b1.onPriceChanging(function(b,price){
	if( price > 100 ){
		console.log("System Error,Price has gone Unexpectedly High : ");		
		return false;
	}
	return true;
});


b1.onPriceChanged(function(b){
	
		console.log("The Book Price Has Changed To  : $"+ b.price());		
		//return false;
	
	return true;
});

b1.price(19.19);
b1.price(200);