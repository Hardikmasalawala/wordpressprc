'use strict';

console.log("Array Example");
var num = ['One','Two','Three','Four'];

var num22 = ['11One','22Two','33Three','44Four'];

var num1 = num[num.length-1];
console.log(num1);
////
Object.defineProperty(num,'last',{ get: function(){
	return this[this.length-1];
}
})
var v1 = num22.last;
console.log("num22.last : "+v1);

////
Object.defineProperty(Array.prototype,'last',{ get: function(){
	return this[this.length-1];
}
})
var v2 = num22.last;
console.log("After define Prototype -num22.last : "+v2);
