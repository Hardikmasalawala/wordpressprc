var Calc = function(start){
var self = this;
	this.add = function(x){

		start = start + x;
		console.log("Add: "+start);
		return this;
	};
	this.multi = function(x){
		start = start * x;
				console.log("Multi :"+start);
		return this;
	};
	this.equal = function(callback){
				
		callback(start);
				console.log("Callback :"+start);
		return this;
	};
}

module.exports = Calc;