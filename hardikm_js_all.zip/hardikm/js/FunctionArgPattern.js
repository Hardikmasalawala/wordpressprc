console.log("myFun(1,2,3,4);");
myFun(1,2,3,4);
function myFun()
{
	var p = 0;
	for (var i = 0; i < arguments.length; i++) {
		console.log("p:"+p);
		p = p + arguments[i];
		console.log("  arguments["+i+"] :"+arguments[i]+" == "+ p);
	}
	console.log("Final Sum :"+p);
	return p;
}


