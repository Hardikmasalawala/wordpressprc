var Calc = function(start){

	this.add = function(x){

		start = start + x;
		console.log("Add: "+start);
		return this;
	};
	this.multi = function(x){
		start = start * x;
				console.log("Multi :"+start);
		return this;
	};
	this.equal = function(callback){
				
		callback(start);
				console.log("Callback :"+start);
		return this;
	};
}
new Calc(0)
	.add(1)
	.add(2)
	.multi(3)
	.equal( function(result){
			console.log("Final result :"+result);
	} );