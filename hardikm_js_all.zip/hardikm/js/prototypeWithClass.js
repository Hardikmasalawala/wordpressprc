'use strict';

class Animal1{
	constructor(voice){
		this.voice = voice || 'grant';
	}
	speak(){
		console.log("value of this.voice :"+ (this.voice));
	}
}

class Cat1 extends Animal1{
	constructor(name,color){
		super('Billu');
		this.name = name;
		this.color = color;
	}
}

 var minnie = new Cat1('minnie','Brown');
 minnie.speak();
 console.log("instace minnie : "+ (minnie));
 console.log("instace minnie constructor: "+ (minnie.constructor));
 console.log("instace minnie __proto__: "+ (minnie.__proto__));
 console.log("instace minnie __proto__.__proto__.hasOwnProperty('speak'): "+ (minnie.__proto__.__proto__.hasOwnProperty('speak')));
 // console.log("minnie.__proto__ : "+ (minnie.__proto__));
 // console.log("minnie.__proto__.__proto__ : "+ (minnie.__proto__.__proto__));
 // console.log("minnie instanceof Animal1 : "+ (Cat1 instanceof Animal1));