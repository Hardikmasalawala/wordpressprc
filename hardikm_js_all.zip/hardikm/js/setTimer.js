
var i=0;
var clickFn= function(){
setInterval(function(){

jQuery.get('/Hardikm/home/data',function(result){
		var html = 'Execution : ';
		i++;
		console.log(html + i);

		//document.write("<br>"+html + i);
		document.getElementById('lblSes').innerHTML= i;
		
});
},1500);


};
var clickFnClear= function(){
i=0;

};